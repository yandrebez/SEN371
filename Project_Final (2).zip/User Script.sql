USE [master]
GO

/* For security reasons the login is created disabled and with a random password. */
/****** Object:  Login [Tam]    Script Date: 2023/08/17 17:03:58 ******/
CREATE LOGIN [Tam] WITH PASSWORD=N'Vc1AeoJh6rQtYUtYd3aQ+/ilDKVvny3ZhJtnhrpAyxM=', DEFAULT_DATABASE=[master], DEFAULT_LANGUAGE=[us_english], CHECK_EXPIRATION=OFF, CHECK_POLICY=OFF
GO

ALTER LOGIN [Tam] DISABLE
GO

ALTER SERVER ROLE [sysadmin] ADD MEMBER [Tam]
GO


