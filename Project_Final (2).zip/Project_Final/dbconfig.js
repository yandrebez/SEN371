const config = {
    user: 'Tam',
    password: 'CJ2BNYyH',
    server: 'localhost',
    database: 'PremierApp',
    trustServerCertificate: true,
};

module.exports = config;