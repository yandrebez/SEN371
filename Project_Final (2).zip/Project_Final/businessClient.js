class businessClient {
    constructor(client_id, client_name, client_surname, client_type, role, address_id, phone_number, email_address){
        this.client_id = client_id,
        this.client_name = client_name,
        this.client_surname =  client_surname,
        this.client_type = client_type,
        this.role = role,
        this.address_id = address_id,
        this.phone_number = phone_number,
        this.email_address = email_address;
    }
}

module.exports = businessClient;