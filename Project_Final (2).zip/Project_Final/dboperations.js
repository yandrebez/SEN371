const businessClient = require('./businessClient');
const serviceAgreement = require('./serviceAgreement');
const client = require('./client');
const job = require('./job');
let config = require('./dbconfig');
const sql = require('mssql');

async function addClient(client) {
    try {
        let pool = await sql.connect(config);
        let insertClientInstance = await pool.request()
        .input('client_name', sql.NVarChar, client.cname)
        .input('client_surname', sql.NVarChar, client.csurname)
        .input('client_type', sql.NVarChar, 'Individual')
        .input('phone_number', sql.NChar, client.contact)
        .input('email_address', sql.NVarChar, client.email)
        .input('street_number', sql.Int, client.strnumber)
        .input('street_name', sql.NVarChar, client.strname)
        .input('suburb', sql.NVarChar, client.suburb)
        .input('city', sql.NVarChar, client.city)
        .input('province', sql.NVarChar, client.province)
        .input('country', sql.NVarChar, client.country)
        .input('postal_code', sql.Int, client.postal)
        .execute('InsertClient');
        return client.redirect_url;
    }
    catch (err) {
        console.log(err);
    }
}

async function addBusinessClient(businessClient) {
    try {
        let pool = await sql.connect(config);
        let insertClientInstance = await pool.request()
        .input('client_name', sql.NVarChar, businessClient.cname)
        .input('client_surname', sql.NVarChar, businessClient.csurname)
        .input('client_type', sql.NVarChar, 'Business')
        .input('role', sql.NVarChar, businessClient.role)
        .input('phone_number', sql.NChar, businessClient.contact)
        .input('email_address', sql.NVarChar, businessClient.email)
        .input('street_number', sql.Int, businessClient.strnumber)
        .input('street_name', sql.NVarChar, businessClient.strname)
        .input('suburb', sql.NVarChar, businessClient.suburb)
        .input('city', sql.NVarChar, businessClient.city)
        .input('province', sql.NVarChar, businessClient.province)
        .input('country', sql.NVarChar, businessClient.country)
        .input('postal_code', sql.Int, businessClient.postal)
        .execute('InsertBusinessClient');
        return businessClient.redirect_url;
    }
    catch (err) {
        console.log(err);
    }
}

async function addJob(job) {
    try {
        let pool = await sql.connect(config);
        let insertSAgreementInstance = await pool.request()
        .input('clients_id', sql.Int, job.cid)
        .input('request_details', sql.NVarChar, job.requestDetails)
        .input('start_timestamp', sql.DateTime2, job.start_timestamp)
        .input('end_timestamp', sql.DateTime2, job.end_timestamp)
        .execute('InsertJob');
        return job.redirect_url;
    }
    catch (err) {
        console.log(err);
    }
}

async function addServiceAgreement(serviceAgreement) {
    try {
        let pool = await sql.connect(config);
        let insertSAgreementInstance = await pool.request()
        .input('clients_id', sql.Int, serviceAgreement.cid)
        .input('service_level_id', sql.Int, serviceAgreement.slevel)
        .input('offering_id', sql.Int, serviceAgreement.service)
        .input('contract_type_id', sql.Int, serviceAgreement.contractType)
        .input('start_date', sql.Date, serviceAgreement.startdate)
        .input('end_date', sql.Date, serviceAgreement.enddate)
        .execute('InsertServiceAgreement');
        return serviceAgreement.redirect_url;
    }
    catch (err) {
        console.log(err);
    }
}

async function getClients() {
    try {
        let pool = await sql.connect(config);
        let clients = await pool.request().query("SELECT * from clients'");
        return clients.output;
    }
    catch (err) {
        console.log(err);
    }
}

async function getClient(client_id) {
    try {
        let pool = await sql.connect(config);
        let client = await pool.request()
        .input('input_parameter', sql.Int, client_id)
        .query("SELECT * from clients WHERE client_id = @input_parameter");
        return client.recordsets;
    }
    catch (err) {
        console.log(err);
    }
}

module.exports = {
    addClient: addClient,
    getClients: getClients,
    getClient: getClient,
    addBusinessClient: addBusinessClient,
    addServiceAgreement: addServiceAgreement,
    addJob: addJob
}