class job {
    constructor(clients_id, request_details, start_timestamp, end_timestamp){
        this.clients_id = clients_id,
        this.request_details = request_details,
        this.start_timestamp = start_timestamp,
        this.end_timestamp = end_timestamp
    }
}

module.exports = job;