const express = require('express');

let config = require('./dbconfig');
const sql = require('mssql');


// creating express app
const app = express();

// listen for requests
app.listen(3000);

// register view engine
app.set('view engine', 'ejs')

// middleware and static files
app.use(express.static('public'));


//redirect
app.get('/home', (req, res) => {
    res.redirect('/');
});

// routes
app.get('/', (req, res) => {
    res.render('home', { title: 'Home'});
  });

  app.get('/BusinessClient', (req, res) => {
    res.render('BusinessClient', { title: 'Business CLient Form'});
  });

  app.get('/businessessTable', (req, res) => {
    console.log('APP Reached');
    sql.connect(config, (err) => {
      if(err) {
        console.log(err);
      }else {
        console.log('DB Connected');
        let request = new sql.Request();
        request.query("SELECT * FROM clients JOIN business_clients ON clients.client_id = business_clients.client_id", (err, records) => {
            if(err) console.log(err);

            // console.log(records.recordset.length);

            res.render('businessessTable', { title: 'Business Clients', data: records });
        });

        //search?
      }
    });
  });
  
  
  app.get('/menu', (req, res) => {
    res.render('menu', { title: 'Navigation'});
  });
  
  app.get('/clientTable', (req, res) => {
    console.log('APP Reached');
    sql.connect(config, (err) => {
      if(err) {
        console.log(err);
      }else {
        console.log('DB Connected');
        let request = new sql.Request();
        request.query("SELECT * FROM clients WHERE client_type = 'Individual'", (err, records) => {
            if(err) console.log(err);

            console.log(records.recordset.length);
            // for(var i = 0; i < records.length)

            res.render('clientTable', { data: records });
        });
      }
    });
  });

  app.get('/individualClient', (req, res) => {
    res.render('individualClient', { title: 'Individual Clients'});
  });

  app.get('/logDetails', (req, res) => {
    res.render('logDetails', { title: 'Log Details'});
  });

  app.get('/managementForm', (req, res) => {
    res.render('managementForm', { title: 'Management Form'});
  });

  app.get('/Reports', (req, res) => {
    res.render('Reports', { title: 'Reports'});
  });

  app.get('/serviceAgreementForm', (req, res) => {
    res.render('serviceAgreementForm', { title: 'Service Agreement Form'});
  });

  app.get('/techniciansTable', (req, res) => {
    console.log('APP Reached');
    sql.connect(config, (err) => {
      if(err) {
        console.log(err);
      }else {
        console.log('DB Connected');
        let request = new sql.Request();
        request.query('SELECT * FROM technicians', (err, records) => {
            if(err) console.log(err);

            console.log(records.recordset.length);
            // for(var i = 0; i < records.length)

            res.render('techniciansTable', { title: 'Technicians', data: records});
        });
      }
    });
  });

  // 404 page
  app.use((req, res) => {
    res.status(404).render('404', { title: 'Page Not Found'});
  });

