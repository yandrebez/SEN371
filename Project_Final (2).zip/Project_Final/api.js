const Db = require('./dboperations');
const Client = require('./client');
const BusinessClient = require('./businessClient');
const serviceAgreement = require('./serviceAgreement');
const job = require('./job');
const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');

const app = express();
const router = express.Router();

app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());
app.use(cors());
app.use('/api', router);
app.use(express.static(__dirname + './views'));


router.route('/individualClient').post((req, res) => {
    console.log("API REACHED");
    let client = { ...req.body }
    Db.addClient(client).then(redirect_url => {
        res.redirect(redirect_url);
    });
});

router.route('/BusinessClient').post((req, res) => {
    console.log("API REACHED");
    let businessClient = { ...req.body }
    Db.addBusinessClient(businessClient).then(redirect_url => {
        res.redirect(redirect_url);
    });
});

router.route('/serviceAgreementForm').post((req, res) => {
    console.log("API REACHED");
    let serviceAgreement = { ...req.body }
    console.log(serviceAgreement);
    Db.addServiceAgreement(serviceAgreement).then(redirect_url => {
        res.redirect(redirect_url);
    });
});

router.route('/logDetails').post((req, res) => {
    console.log("API REACHED");
    let job = { ...req.body }
    console.log(job);
    Db.addJob(job).then(redirect_url => {
        res.redirect(redirect_url);
    });
});

const port = process.env.PORT || 8090;
app.listen(port);
console.log('REST API is running at ' + port);