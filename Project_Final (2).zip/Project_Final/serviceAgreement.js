class serviceAgreement {
    constructor(clients_id, service_level_id, offering_id, contract_type_id, start_date, end_date){
        this.clients_id = clients_id,
        this.service_level_id = service_level_id,
        this.offering_id = offering_id,
        this.contract_type_id = contract_type_id,
        this.start_date = start_date,
        this.end_date = end_date
    }
}

module.exports = serviceAgreement;