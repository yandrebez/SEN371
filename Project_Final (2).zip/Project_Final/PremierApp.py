from flask import Flask, render_template, request
import asyncio
from telegram import Bot
from telegram.error import TelegramError

app = Flask(__name__)

bot_token = "6403441889:AAF9gG7h9hRMPMANPmfV_l6wjY-4yGNoAkU"
channel_username = "@PremierserviceSolutions"  

# Initialize the bot
bot = Bot(token=bot_token)

@app.route("/", methods=["GET", "POST"])
def index():
    if request.method == "POST":
        client_name = request.form.get("client_name")
        client_number = request.form.get("client_number")
        issue = request.form.get("issue")

        if client_name and client_number and issue:  # Check if all fields are filled
            report_data = f"Client Name: {client_name}\nClient Number: {client_number}\nIssue: {issue}"

            try:
                loop = asyncio.new_event_loop()
                asyncio.set_event_loop(loop)
                loop.run_until_complete(send_notification(report_data))
                loop.close()
                return "Report submitted successfully!"
            except Exception as e:
                return f"Error submitting report: {e}"
        else:
            return "Please fill in all fields before submitting."

    return render_template("index.html")

async def send_notification(report_data):
    try:
        message = f"New report submitted:\n{report_data}"
        await bot.send_message(chat_id=channel_username, text=message)
        print("Notification sent successfully!")
    except TelegramError as e:
        print(f"Error sending notification: {e}")

if __name__ == "__main__":
    app.run()
